# How to Post This to GitHub

A simple, step-by-step guide — no experience needed.

---

## What you'll need

- A free GitHub account ([github.com](https://github.com))
- The three files from this folder:
  - `Grounded_SAM2_Inference.ipynb` — the notebook
  - `README.md` — the project description
  - `.gitignore` — tells GitHub what to ignore

---

## Step 1 — Create a GitHub account (if you don't have one)

1. Go to [github.com/signup](https://github.com/signup)
2. Enter your email, create a password, choose a username
3. Verify your email address

---

## Step 2 — Create a new repository

A "repository" (or "repo") is just a folder for your project on GitHub.

1. Once logged in, click the **green "New"** button in the top-left, or go to [github.com/new](https://github.com/new)
2. Fill in:
   - **Repository name:** `grounded-sam2-inference` (or whatever you like)
   - **Description:** `Object segmentation with Grounding DINO + SAM 2` (optional)
   - **Visibility:** Public ✅ (so others can find and use it)
   - ✅ Check **"Add a README file"** — we'll replace it in a moment
3. Click **"Create repository"**

---

## Step 3 — Upload the files

You're now on your new repo's page. Here's how to upload:

1. Click **"Add file" → "Upload files"**
2. Drag and drop (or click to browse) and select these files:
   - `Grounded_SAM2_Inference.ipynb`
   - `README.md`
   - `.gitignore`

   > ⚠️ Note: `.gitignore` starts with a dot — it may be hidden on Mac/Windows.
   > On Mac: press **Cmd+Shift+.** in Finder to show hidden files.
   > On Windows: in File Explorer, check **"Hidden items"** under the View tab.

3. Scroll down to **"Commit changes"**
4. Leave the default message ("Add files via upload") or write your own
5. Click **"Commit changes"**

---

## Step 4 — Replace the placeholder README

GitHub auto-created a basic README. Since you uploaded your own:

1. Click on `README.md` in your file list
2. Click the **pencil icon** (Edit) in the top right
3. Select all the text and delete it
4. Open your `README.md` file on your computer (it's a plain text file — open with Notepad/TextEdit)
5. Copy everything and paste it into the GitHub editor
6. Click **"Commit changes"**

> Or just delete the auto-created README first (click the file → three dots menu → Delete), then upload yours. Either works!

---

## Step 5 — Check your repo

Go back to your repo's main page (`github.com/YOUR_USERNAME/grounded-sam2-inference`).

You should see:
- ✅ Your notebook file listed
- ✅ Your README rendered below as a nicely formatted page
- ✅ A `.gitignore` file

That's it — your project is live on GitHub! 🎉

---

## Optional: Add a "Open in Colab" button

This makes it one click for anyone to run your notebook. Add this line to the top of your README (replacing `YOUR_USERNAME` and `YOUR_REPO_NAME`):

```
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/YOUR_USERNAME/YOUR_REPO_NAME/blob/main/Grounded_SAM2_Inference.ipynb)
```

---

## Sharing your project

Your repo URL will be:
```
https://github.com/YOUR_USERNAME/grounded-sam2-inference
```

Share that link anywhere — anyone can view the code and open the notebook in Colab directly from GitHub.
